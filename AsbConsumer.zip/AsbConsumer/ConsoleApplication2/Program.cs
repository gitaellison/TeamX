﻿namespace AsbConsumer
{
    using Microsoft.ServiceBus.Messaging;
    using System;
    using System.IO;
    using System.Runtime.Serialization;
    using System.ServiceModel.Channels;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using System.Xml;

    class Program
    {
        static void Main(string[] args)
        {
            QueueConnector.Initialize();
            BrokeredMessage message;
            while (QueueConnector.ClaimsClient.Receive() != null)
            {
                message = QueueConnector.ClaimsClient.Receive();
                Console.WriteLine(string.Format("Message received: {0}, {1}, {2}", message.SequenceNumber, message.Label, message.MessageId));
                Stream stream = message.GetBody<Stream>();
                StreamReader reader = new StreamReader(stream);
                string s = reader.ReadToEnd();
                Console.WriteLine(s);
                message.Complete();

                Console.WriteLine("Processing message (sleeping...)");
                Thread.Sleep(1000);
            }

        }
    }
}